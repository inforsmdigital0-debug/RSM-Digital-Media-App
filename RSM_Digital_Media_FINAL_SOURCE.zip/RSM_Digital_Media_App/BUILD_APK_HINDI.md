# RSM DIGITAL MEDIA — APK Build

यह Android source project Supabase project के साथ configured है.

## Supabase
- URL: https://vqennkydwotglvghjyyx.supabase.co
- Client-safe Publishable Key project source में configured है.
- `create-client` Edge Function source: `backend/supabase/functions/create-client/index.ts`

## APK बनाने के लिए
1. Android Studio में इस folder को Open करें.
2. Gradle sync पूरा होने दें.
3. Build > Build APK(s) चुनें.
4. APK `app/build/outputs/apk/debug/` में मिलेगा.

## महत्वपूर्ण
- Service-role/secret key APK में न डालें.
- Admin login और client account backend Supabase Auth/profile से चलते हैं.
- Database schema `backend/sql/schema.sql` में है.
