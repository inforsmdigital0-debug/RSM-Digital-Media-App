create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 user_id text unique not null,
 full_name text,
 role text not null default 'client' check(role in ('admin','client')),
 created_at timestamptz not null default now()
);

create table if not exists public.songs (
 id uuid primary key default gen_random_uuid(),
 client_id uuid not null references public.profiles(id) on delete cascade,
 title text not null,
 artist text,
 album text,
 year int,
 genre text,
 duration text,
 description text,
 poster_path text,
 audio_path text,
 approved boolean not null default false,
 rejection_reason text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create index if not exists songs_client_idx on public.songs(client_id);
create index if not exists songs_genre_idx on public.songs(genre);
create index if not exists songs_approved_idx on public.songs(approved);

alter table public.profiles enable row level security;
alter table public.songs enable row level security;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

drop policy if exists "profiles self or admin" on public.profiles;
create policy "profiles self or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());

drop policy if exists "songs catalog own or admin" on public.songs;
create policy "songs catalog own or admin" on public.songs for select to authenticated
using (approved=true or client_id=auth.uid() or public.is_admin());

drop policy if exists "client insert own" on public.songs;
create policy "client insert own" on public.songs for insert to authenticated
with check (client_id=auth.uid());

drop policy if exists "client update own or admin" on public.songs;
create policy "client update own or admin" on public.songs for update to authenticated
using (client_id=auth.uid() or public.is_admin())
with check (client_id=auth.uid() or public.is_admin());

drop policy if exists "client delete own or admin" on public.songs;
create policy "client delete own or admin" on public.songs for delete to authenticated
using (client_id=auth.uid() or public.is_admin());

-- Create these as PRIVATE buckets in Supabase Dashboard:
-- posters, songs
-- Storage RLS policies allow clients to use only their own folder and admins to manage all.

insert into storage.buckets (id,name,public) values ('posters','posters',false) on conflict (id) do update set public=false;
insert into storage.buckets (id,name,public) values ('songs','songs',false) on conflict (id) do update set public=false;

drop policy if exists "poster insert own folder" on storage.objects;
create policy "poster insert own folder" on storage.objects for insert to authenticated
with check (bucket_id='posters' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "poster read own approved admin" on storage.objects;
create policy "poster read own approved admin" on storage.objects for select to authenticated
using (bucket_id='posters' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists "poster update own admin" on storage.objects;
create policy "poster update own admin" on storage.objects for update to authenticated
using (bucket_id='posters' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists "poster delete own admin" on storage.objects;
create policy "poster delete own admin" on storage.objects for delete to authenticated
using (bucket_id='posters' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists "song insert own folder" on storage.objects;
create policy "song insert own folder" on storage.objects for insert to authenticated
with check (bucket_id='songs' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "song read own admin" on storage.objects;
create policy "song read own admin" on storage.objects for select to authenticated
using (bucket_id='songs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists "song update own admin" on storage.objects;
create policy "song update own admin" on storage.objects for update to authenticated
using (bucket_id='songs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists "song delete own admin" on storage.objects;
create policy "song delete own admin" on storage.objects for delete to authenticated
using (bucket_id='songs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
