# RSM DIGITAL MEDIA — Client Song Submission App v2

A free-stack Android client submission portal using Supabase Free.

## Included
- Admin/client login
- Admin creates client accounts through a protected Edge Function
- Client password change
- Song + poster + audio upload
- Title, artist, album, year, genre, duration, description
- Private Storage buckets with per-user folder policies
- Client can edit/delete only own submissions
- Admin review and approval/rejection
- Only approved songs appear in public catalog
- Basic catalog and search field

## Setup
1. Create a Supabase Free project.
2. Run `backend/sql/schema.sql` in SQL Editor.
3. Create the first auth user in Authentication > Users.
4. Insert the first admin profile in SQL Editor:
   `insert into public.profiles(id,user_id,full_name,role) values ('AUTH_USER_UUID','your-email','RSM Admin','admin');`
5. Deploy `backend/supabase/functions/create-client` and set `SUPABASE_SERVICE_ROLE_KEY` as an Edge Function secret. Never put it in the APK.
6. In `MainActivity.java`, confirm URL and Publishable key.
7. Build with Android Studio using `Build > Generate Signed App Bundle / APK`.

## Important
The source is configured for the Supabase project supplied by the user. This environment does not have the Android SDK/Gradle toolchain, so a binary APK cannot be compiled here.
