# RSM DIGITAL MEDIA — Free Setup (Hindi)

### 1. Database
Supabase → SQL Editor → पूरा `backend/sql/schema.sql` paste करके Run करें.

### 2. Admin बनाना
Supabase → Authentication → Users → Add user करके अपना admin email/password बनाइए.
फिर SQL Editor में:
```sql
insert into public.profiles(id,user_id,full_name,role)
values ('AUTH_USER_UUID','info.rsmdigital0@gmail.com','RSM Digital Media Admin','admin');
```
`AUTH_USER_UUID` को Authentication वाले user के UUID से बदलें.

### 3. Client account
App में Admin login → Create Client Account. इसके लिए `create-client` Edge Function deploy करनी होगी और केवल Function secret में `SUPABASE_SERVICE_ROLE_KEY` रखना होगा.

### 4. Storage
SQL schema private `posters` और `songs` buckets तथा RLS policies बनाता है.

### 5. App
`MainActivity.java` में project URL और Publishable key configured हैं. Secret/service-role key APK में कभी न डालें.

### 6. APK
Android Studio में project खोलें → Build → Generate Signed App Bundle / APK → APK.

यह पूरा setup paid hosting पर निर्भर नहीं है; Supabase Free limits लागू रहेंगी.
