import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

Deno.serve(async (req) => {
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const auth = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') || '' } }
    });
    const { data: { user } } = await auth.auth.getUser();
    if (!user) return new Response('Unauthorized', { status: 401 });

    const admin = createClient(supabaseUrl, serviceKey);
    const { data: profile } = await admin.from('profiles').select('role').eq('id', user.id).single();
    if (profile?.role !== 'admin') return new Response('Admin only', { status: 403 });

    const { user_id, password, full_name } = await req.json();
    if (!user_id || !password) return new Response('user_id and password are required', { status: 400 });
    if (String(password).length < 6) return new Response('Password must be at least 6 characters', { status: 400 });

    const { data, error } = await admin.auth.admin.createUser({
      email: String(user_id).trim(),
      email_confirm: true,
      password: String(password)
    });
    if (error) throw error;

    const { error: profileError } = await admin.from('profiles').insert({
      id: data.user.id,
      user_id: String(user_id).trim(),
      full_name: full_name || '',
      role: 'client'
    });
    if (profileError) {
      await admin.auth.admin.deleteUser(data.user.id);
      throw profileError;
    }
    return Response.json({ ok: true, id: data.user.id });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }
});
